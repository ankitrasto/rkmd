#!/bin/bash

xterm -hold -e "java -Dswing.defaultlaf=com.sun.java.swing.plaf.gtk.GTKLookAndFeel -Dswing.aatext=TRUE -Dawt.useSystemAAFontSettings=on -jar ./raeLipidGUI.jar"

